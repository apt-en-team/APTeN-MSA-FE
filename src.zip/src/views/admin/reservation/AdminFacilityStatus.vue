<script setup>
// 관리자 시설 상태 페이지 placeholder입니다.
</script>

<template>
  <section class="page-container">
    <h1 class="page-title">시설 상태</h1>
    <div class="card-section">관리자 시설 상태 페이지 placeholder</div>
  </section>
</template>
