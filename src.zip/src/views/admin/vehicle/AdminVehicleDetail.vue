<script setup>
// 관리자 차량 상세 페이지 placeholder입니다.
</script>

<template>
  <section class="page-container">
    <h1 class="page-title">차량 상세</h1>
    <div class="card-section">관리자 차량 상세 페이지 placeholder</div>
  </section>
</template>
