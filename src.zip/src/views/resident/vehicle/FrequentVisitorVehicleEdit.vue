<script setup>
// 자주 방문 차량 수정 페이지 placeholder입니다.
</script>

<template>
  <section class="page-container">
    <h1 class="page-title">자주 방문 차량 수정</h1>
    <div class="card-section">자주 방문 차량 수정 페이지 placeholder</div>
  </section>
</template>
