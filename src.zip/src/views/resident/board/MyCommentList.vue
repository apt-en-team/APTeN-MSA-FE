<template>
  <section class="page">
    <h1>MyCommentList</h1>
    <p>TODO: 최신 명세 기준으로 화면 구현 예정</p>
  </section>
</template>

<script setup>
// TODO: API 연동 및 화면 로직 구현 예정
</script>

<style scoped>
.page {
  padding: 20px 16px 88px;
}
</style>
