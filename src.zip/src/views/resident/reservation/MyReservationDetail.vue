<script setup>
// 내 예약 상세 페이지 placeholder입니다.
</script>

<template>
  <section class="page-container">
    <h1 class="page-title">내 예약 상세</h1>
    <div class="card-section">내 예약 상세 페이지 placeholder</div>
  </section>
</template>
